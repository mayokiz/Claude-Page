package com.claudepage.app

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.CalendarView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

val BG = Color.parseColor("#F5F4EE")
val INK = Color.parseColor("#141413")
val MUTED = Color.parseColor("#6B6A64")
val ACCENT = Color.parseColor("#D97757")
val CARD = Color.parseColor("#FBFAF6")
val LINE = Color.parseColor("#E3E1D8")

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun lp(w: Int = -1, h: Int = -2, top: Int = 0) = LinearLayout.LayoutParams(w, h).apply { topMargin = top }

fun Context.label(s: String, size: Float = 15f, color: Int = INK, serif: Boolean = false): TextView {
    val t = TextView(this)
    t.text = s
    t.textSize = size
    t.setTextColor(color)
    if (serif) t.typeface = Typeface.SERIF
    return t
}

fun Context.card(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(16), dp(14), dp(16), dp(14))
    val g = GradientDrawable()
    g.setColor(CARD)
    g.cornerRadius = dp(16).toFloat()
    g.setStroke(dp(1), LINE)
    l.background = g
    return l
}

fun Context.button(s: String, onClick: () -> Unit): TextView {
    val t = label(s, 15f, Color.WHITE, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(18), dp(12), dp(18), dp(12))
    val g = GradientDrawable()
    g.setColor(ACCENT)
    g.cornerRadius = dp(24).toFloat()
    t.background = g
    t.setOnClickListener { onClick() }
    return t
}

class MainActivity : Activity() {
    private lateinit var body: FrameLayout
    private var tab = 0
    private val tabs = listOf("Notes", "Reminders", "Calendar", "Assistant")
    private val tabViews = mutableListOf<TextView>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(22), dp(18), dp(22), dp(8))
        head.addView(label("Claude Page", 28f, INK, true), LinearLayout.LayoutParams(0, -2, 1f))
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_burst)
        head.addView(logo, LinearLayout.LayoutParams(dp(38), dp(38)))
        root.addView(head)

        body = FrameLayout(this)
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val bar = LinearLayout(this)
        bar.setPadding(dp(8), dp(4), dp(8), dp(8))
        tabs.forEachIndexed { i, t ->
            val v = label(t, 13f, MUTED, true)
            v.gravity = Gravity.CENTER
            v.setPadding(0, dp(12), 0, dp(12))
            v.setOnClickListener { show(i) }
            tabViews.add(v)
            bar.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bar)
        setContentView(root)
        if (b == null) handleShare(intent)
        show(0)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        handleShare(i)
        show(0)
    }

    private fun handleShare(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        val t = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val l = Store.notes(this)
        val now = System.currentTimeMillis()
        l.add(Note(now, i.getStringExtra(Intent.EXTRA_SUBJECT) ?: "Shared", t, now))
        Store.saveNotes(this, l)
    }

    private fun show(i: Int) {
        tab = i
        tabViews.forEachIndexed { j, v -> v.setTextColor(if (j == i) ACCENT else MUTED) }
        body.removeAllViews()
        val v = when (i) {
            0 -> notesView()
            1 -> remindersView()
            2 -> calendarView()
            else -> assistantView()
        }
        body.addView(v)
    }

    private fun page(views: List<View>): ScrollView {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(20))
        views.forEach { col.addView(it, lp(top = dp(10))) }
        val s = ScrollView(this)
        s.addView(col)
        return s
    }

    // ---- Notes
    private fun notesView(): View {
        val items = mutableListOf<View>(button("New note") { editNote(null) })
        Store.notes(this).sortedByDescending { it.updated }.forEach { n ->
            val c = card()
            c.addView(label(n.title.ifBlank { "Untitled" }, 18f, INK, true))
            if (n.body.isNotBlank()) c.addView(label(n.body, 14f, MUTED), lp(top = dp(4)))
            c.setOnClickListener { editNote(n) }
            items.add(c)
        }
        if (items.size == 1) items.add(label("No notes yet.", 15f, MUTED, true))
        return page(items)
    }

    private fun editNote(n: Note?) {
        val t = EditText(this)
        t.hint = "Title"
        t.typeface = Typeface.SERIF
        t.textSize = 18f
        t.setText(n?.title ?: "")
        val b = EditText(this)
        b.hint = "Write something"
        b.minLines = 6
        b.gravity = Gravity.TOP
        b.setText(n?.body ?: "")
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), 0)
        col.addView(t)
        col.addView(b)
        val d = AlertDialog.Builder(this).setView(col)
        d.setPositiveButton("Save") { _, _ ->
            val list = Store.notes(this)
            val now = System.currentTimeMillis()
            val ex = if (n == null) null else list.find { it.id == n.id }
            if (ex != null) {
                ex.title = t.text.toString(); ex.body = b.text.toString(); ex.updated = now
            } else {
                list.add(Note(now, t.text.toString(), b.text.toString(), now))
            }
            Store.saveNotes(this, list)
            show(0)
        }
        d.setNegativeButton("Cancel", null)
        if (n != null) {
            d.setNeutralButton("Delete") { _, _ ->
                Store.saveNotes(this, Store.notes(this).filter { it.id != n.id })
                show(0)
            }
        }
        d.show()
    }

    // ---- Reminders
    private fun remindersView(): View {
        val items = mutableListOf<View>(button("New reminder") { addReminder(null) })
        Store.reminders(this).sortedBy { it.time }.forEach { items.add(reminderCard(it)) }
        if (items.size == 1) items.add(label("No reminders yet.", 15f, MUTED, true))
        return page(items)
    }

    private fun reminderCard(r: Reminder): View {
        val c = card()
        val tv = label(r.text, 17f, if (r.done) MUTED else INK, true)
        if (r.done) tv.paintFlags = tv.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
        c.addView(tv)
        c.addView(label(fmt(r.time) + (if (r.done) "  (done)" else ""), 13f, MUTED), lp(top = dp(4)))
        c.setOnClickListener {
            val l = Store.reminders(this)
            val x = l.find { it.id == r.id }
            if (x != null) {
                x.done = !x.done
                if (x.done) Alarms.cancel(this, x) else Alarms.set(this, x)
            }
            Store.saveReminders(this, l)
            show(tab)
        }
        c.setOnLongClickListener {
            Alarms.cancel(this, r)
            Store.saveReminders(this, Store.reminders(this).filter { it.id != r.id })
            show(tab)
            true
        }
        return c
    }

    private fun addReminder(day: Calendar?) {
        val input = EditText(this)
        input.hint = "Remind me to..."
        AlertDialog.Builder(this).setTitle("New reminder").setView(input)
            .setPositiveButton("Next") { _, _ ->
                val text = input.text.toString().ifBlank { "Reminder" }
                val c = day ?: Calendar.getInstance()
                DatePickerDialog(this, { _, y, m, d ->
                    TimePickerDialog(this, { _, h, mi ->
                        c.set(y, m, d, h, mi, 0)
                        val r = Reminder(System.currentTimeMillis(), text, c.timeInMillis, false)
                        val l = Store.reminders(this)
                        l.add(r)
                        Store.saveReminders(this, l)
                        Alarms.set(this, r)
                        show(tab)
                    }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---- Calendar
    private fun calendarView(): View {
        val cal = Calendar.getInstance()
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        fun refresh() {
            list.removeAllViews()
            val d = cal.clone() as Calendar
            d.set(Calendar.HOUR_OF_DAY, 0); d.set(Calendar.MINUTE, 0); d.set(Calendar.SECOND, 0); d.set(Calendar.MILLISECOND, 0)
            val s = d.timeInMillis
            val rs = Store.reminders(this).filter { it.time >= s && it.time < s + 86400000L }.sortedBy { it.time }
            list.addView(label(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(cal.time), 18f, INK, true))
            if (rs.isEmpty()) list.addView(label("Nothing planned.", 14f, MUTED), lp(top = dp(6)))
            rs.forEach { list.addView(reminderCard(it), lp(top = dp(8))) }
        }
        val cv = CalendarView(this)
        cv.setOnDateChangeListener { _, y, m, d -> cal.set(y, m, d); refresh() }
        refresh()
        val add = button("Add reminder on this day") { addReminder(cal.clone() as Calendar) }
        return page(listOf(cv, add, list))
    }

    // ---- Assistant
    private fun assistantView(): View {
        val out = label("Ask about your notes, plan your day, or draft something.", 15f, MUTED, true)
        val inp = EditText(this)
        inp.hint = "Message"
        inp.minLines = 2
        val send = button("Send") {
            val key = Store.key(this)
            val q = inp.text.toString()
            if (key.isBlank()) { askKey() }
            else if (q.isNotBlank()) {
                out.text = "Thinking..."
                val sys = ("You are the assistant inside the Claude Page app. Now: " + Date() +
                    ". Notes: " + Store.notes(this).joinToString("; ") { it.title + ": " + it.body } +
                    ". Reminders: " + Store.reminders(this).joinToString("; ") { it.text + " at " + fmt(it.time) }).take(3000)
                Thread {
                    val reply = try {
                        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                        c.requestMethod = "POST"
                        c.doOutput = true
                        c.setRequestProperty("content-type", "application/json")
                        c.setRequestProperty("x-api-key", key)
                        c.setRequestProperty("anthropic-version", "2023-06-01")
                        val req = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 1024).put("system", sys)
                            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
                        c.outputStream.use { it.write(req.toString().toByteArray()) }
                        val ok = c.responseCode < 400
                        val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
                        if (ok) JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text")
                        else "Error " + c.responseCode + ": " + txt
                    } catch (e: Exception) {
                        "Failed: " + e.message
                    }
                    runOnUiThread { out.text = reply }
                }.start()
            }
        }
        return page(listOf(out, inp, send, button("Set API key") { askKey() }))
    }

    private fun askKey() {
        val e = EditText(this)
        e.hint = "Anthropic API key"
        AlertDialog.Builder(this).setTitle("API key").setView(e)
            .setPositiveButton("Save") { _, _ -> Store.setKey(this, e.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }
}
