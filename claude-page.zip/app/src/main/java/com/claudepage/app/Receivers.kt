package com.claudepage.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("reminders", "Reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, "reminders")
            .setSmallIcon(R.drawable.ic_burst)
            .setContentTitle("Claude Page")
            .setContentText(i.getStringExtra("text") ?: "Reminder")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify((i.getLongExtra("id", 0L) and 0x7fffffffL).toInt(), n)
        Widgets.refresh(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.reminders(c).forEach { Alarms.set(c, it) }
    }
}

abstract class BaseWidget : AppWidgetProvider() {
    abstract fun fill(c: Context, v: RemoteViews)

    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) {
            val v = RemoteViews(c.packageName, R.layout.widget_card)
            fill(c, v)
            val pi = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.root, pi)
            m.updateAppWidget(id, v)
        }
    }
}

class NextWidget : BaseWidget() {
    override fun fill(c: Context, v: RemoteViews) {
        val now = System.currentTimeMillis()
        val r = Store.reminders(c).filter { !it.done && it.time > now }.minByOrNull { it.time }
        v.setTextViewText(R.id.w_label, "Next reminder")
        v.setTextViewText(R.id.w_title, r?.text ?: "Nothing coming up")
        v.setTextViewText(R.id.w_body, if (r != null) fmt(r.time) else "Open Claude Page to add one")
    }
}

class NoteWidget : BaseWidget() {
    override fun fill(c: Context, v: RemoteViews) {
        val n = Store.notes(c).maxByOrNull { it.updated }
        v.setTextViewText(R.id.w_label, "Latest note")
        v.setTextViewText(R.id.w_title, n?.title?.ifBlank { "Untitled" } ?: "No notes yet")
        v.setTextViewText(R.id.w_body, n?.body ?: "Open Claude Page to write one")
    }
}
