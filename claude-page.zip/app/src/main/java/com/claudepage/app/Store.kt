package com.claudepage.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Note(val id: Long, var title: String, var body: String, var updated: Long)
data class Reminder(val id: Long, var text: String, var time: Long, var done: Boolean)

fun fmt(t: Long): String = SimpleDateFormat("EEE d MMM, HH:mm", Locale.getDefault()).format(Date(t))

object Store {
    private fun p(c: Context) = c.getSharedPreferences("claude_page", Context.MODE_PRIVATE)

    fun notes(c: Context): MutableList<Note> {
        val out = mutableListOf<Note>()
        val a = JSONArray(p(c).getString("notes", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Note(o.getLong("id"), o.getString("title"), o.getString("body"), o.getLong("updated")))
        }
        return out
    }

    fun saveNotes(c: Context, l: List<Note>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("body", it.body).put("updated", it.updated)) }
        p(c).edit().putString("notes", a.toString()).apply()
        Widgets.refresh(c)
    }

    fun reminders(c: Context): MutableList<Reminder> {
        val out = mutableListOf<Reminder>()
        val a = JSONArray(p(c).getString("reminders", "[]"))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out.add(Reminder(o.getLong("id"), o.getString("text"), o.getLong("time"), o.getBoolean("done")))
        }
        return out
    }

    fun saveReminders(c: Context, l: List<Reminder>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("text", it.text).put("time", it.time).put("done", it.done)) }
        p(c).edit().putString("reminders", a.toString()).apply()
        Widgets.refresh(c)
    }

    fun key(c: Context): String = p(c).getString("api_key", "") ?: ""
    fun setKey(c: Context, k: String) { p(c).edit().putString("api_key", k).apply() }
}

object Alarms {
    private fun pi(c: Context, r: Reminder): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java).putExtra("text", r.text).putExtra("id", r.id)
        return PendingIntent.getBroadcast(c, (r.id and 0x7fffffffL).toInt(), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun set(c: Context, r: Reminder) {
        if (r.done || r.time <= System.currentTimeMillis()) return
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.time, pi(c, r))
    }

    fun cancel(c: Context, r: Reminder) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(c, r))
    }
}

object Widgets {
    fun refresh(c: Context) {
        val m = AppWidgetManager.getInstance(c)
        listOf<BaseWidget>(NextWidget(), NoteWidget()).forEach { w ->
            val ids = m.getAppWidgetIds(ComponentName(c, w.javaClass))
            if (ids.isNotEmpty()) w.onUpdate(c, m, ids)
        }
    }
}
